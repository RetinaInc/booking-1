-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 17, 2011 at 05:00 PM
-- Server version: 5.1.49
-- PHP Version: 5.3.3-1ubuntu9.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `websiteclub`
--

-- --------------------------------------------------------

--
-- Table structure for table `be_acl_actions`
--

CREATE TABLE IF NOT EXISTS `be_acl_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(254) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `be_acl_actions`
--


-- --------------------------------------------------------

--
-- Table structure for table `be_acl_groups`
--

CREATE TABLE IF NOT EXISTS `be_acl_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lft` int(10) unsigned NOT NULL DEFAULT '0',
  `rgt` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(254) NOT NULL,
  `link` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `be_acl_groups`
--

INSERT INTO `be_acl_groups` (`id`, `lft`, `rgt`, `name`, `link`) VALUES
(1, 1, 6, 'Member', NULL),
(2, 4, 5, 'Administrator', NULL),
(3, 2, 3, 'demoadmin', 0);

-- --------------------------------------------------------

--
-- Table structure for table `be_acl_permissions`
--

CREATE TABLE IF NOT EXISTS `be_acl_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) unsigned NOT NULL DEFAULT '0',
  `aco_id` int(10) unsigned NOT NULL DEFAULT '0',
  `allow` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `aro_id` (`aro_id`),
  KEY `aco_id` (`aco_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `be_acl_permissions`
--

INSERT INTO `be_acl_permissions` (`id`, `aro_id`, `aco_id`, `allow`) VALUES
(1, 2, 1, 'Y'),
(2, 1, 2, 'Y'),
(3, 1, 24, 'Y'),
(4, 1, 27, 'N'),
(5, 1, 6, 'N'),
(6, 1, 3, 'N'),
(7, 1, 12, 'N'),
(8, 3, 24, 'Y'),
(9, 3, 12, 'N'),
(10, 3, 28, 'Y');

-- --------------------------------------------------------

--
-- Table structure for table `be_acl_permission_actions`
--

CREATE TABLE IF NOT EXISTS `be_acl_permission_actions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `access_id` int(10) unsigned NOT NULL DEFAULT '0',
  `axo_id` int(10) unsigned NOT NULL DEFAULT '0',
  `allow` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `access_id` (`access_id`),
  KEY `axo_id` (`axo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `be_acl_permission_actions`
--


-- --------------------------------------------------------

--
-- Table structure for table `be_acl_resources`
--

CREATE TABLE IF NOT EXISTS `be_acl_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lft` int(10) unsigned NOT NULL DEFAULT '0',
  `rgt` int(10) unsigned NOT NULL DEFAULT '0',
  `name` varchar(254) NOT NULL,
  `link` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `lft` (`lft`),
  KEY `rgt` (`rgt`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `be_acl_resources`
--

INSERT INTO `be_acl_resources` (`id`, `lft`, `rgt`, `name`, `link`) VALUES
(1, 1, 70, 'Site', NULL),
(2, 50, 69, 'Control Panel', NULL),
(3, 51, 68, 'System', NULL),
(4, 62, 63, 'Members', NULL),
(5, 52, 61, 'Access Control', NULL),
(6, 64, 65, 'Settings', NULL),
(7, 66, 67, 'Utilities', NULL),
(8, 59, 60, 'Permissions', NULL),
(9, 57, 58, 'Groups', NULL),
(10, 55, 56, 'Resources', NULL),
(11, 53, 54, 'Actions', NULL),
(12, 26, 49, 'General', 0),
(13, 47, 48, 'Calendar', 0),
(14, 45, 46, 'Categories', 0),
(15, 43, 44, 'Customers', 0),
(16, 41, 42, 'Menus', 0),
(17, 39, 40, 'Messages', 0),
(18, 37, 38, 'Orders', 0),
(19, 35, 36, 'Pages', 0),
(20, 33, 34, 'Products', 0),
(21, 31, 32, 'Subscribers', 0),
(22, 29, 30, 'Admins', 0),
(23, 27, 28, 'Filemanager', 0),
(24, 18, 25, 'Customer Support', 0),
(25, 23, 24, 'Purchase Support', 0),
(26, 21, 22, 'Customer Record', 0),
(27, 19, 20, 'Customers Admin', 0),
(28, 12, 17, 'Project Panel', 0),
(29, 15, 16, 'Project Spec', 0),
(30, 13, 14, 'Project Home', 0),
(31, 2, 11, 'Booking', 0),
(32, 9, 10, 'Customer booking', 0),
(33, 7, 8, 'Bookings', 0),
(34, 5, 6, 'Courses', 0),
(35, 3, 4, 'Trainers', 0);

-- --------------------------------------------------------

--
-- Table structure for table `be_groups`
--

CREATE TABLE IF NOT EXISTS `be_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `disabled` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `be_groups`
--

INSERT INTO `be_groups` (`id`, `locked`, `disabled`) VALUES
(1, 1, 0),
(2, 1, 0),
(3, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `be_preferences`
--

CREATE TABLE IF NOT EXISTS `be_preferences` (
  `name` varchar(254) CHARACTER SET latin1 NOT NULL,
  `value` text CHARACTER SET latin1 NOT NULL,
  KEY `name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `be_preferences`
--

INSERT INTO `be_preferences` (`name`, `value`) VALUES
('default_user_group', '1'),
('smtp_host', ''),
('keep_error_logs_for', '30'),
('email_protocol', 'mail'),
('use_registration_captcha', '0'),
('page_debug', '0'),
('automated_from_name', 'BackendPro'),
('allow_user_registration', '0'),
('use_login_captcha', '0'),
('site_name', 'Codeigniter Application Demos'),
('automated_from_email', 'noreply@backendpro.co.uk'),
('account_activation_time', '7'),
('allow_user_profiles', '1'),
('activation_method', 'email'),
('autologin_period', '30'),
('min_password_length', '4'),
('smtp_user', ''),
('smtp_pass', ''),
('email_mailpath', '/usr/sbin/sendmail -t -i'),
('smtp_port', '25'),
('smtp_timeout', '5'),
('email_wordwrap', '1'),
('email_wrapchars', '76'),
('email_mailtype', 'text'),
('email_charset', 'utf-8'),
('bcc_batch_mode', '0'),
('bcc_batch_size', '200'),
('login_field', 'email'),
('main_nav_parent_id', '107'),
('categories_parent_id', '1'),
('admin_email', 'admin@gmail.com'),
('webshop_slideshow', 'nivoslider'),
('slideshow_two', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `be_resources`
--

CREATE TABLE IF NOT EXISTS `be_resources` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `locked` tinyint(1) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `be_resources`
--

INSERT INTO `be_resources` (`id`, `locked`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 0),
(13, 0),
(14, 0),
(15, 0),
(16, 0),
(17, 0),
(18, 0),
(19, 0),
(20, 0),
(21, 0),
(22, 0),
(23, 0),
(24, 0),
(25, 0),
(26, 0),
(27, 0),
(28, 0),
(29, 0),
(30, 0),
(31, 0),
(32, 0),
(33, 0),
(34, 0),
(35, 0);

-- --------------------------------------------------------

--
-- Table structure for table `be_users`
--

CREATE TABLE IF NOT EXISTS `be_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(32) NOT NULL,
  `password` varchar(40) NOT NULL,
  `email` varchar(254) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `group` int(10) unsigned DEFAULT NULL,
  `activation_key` varchar(32) DEFAULT NULL,
  `last_visit` datetime DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `password` (`password`),
  KEY `group` (`group`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `be_users`
--

INSERT INTO `be_users` (`id`, `username`, `password`, `email`, `active`, `group`, `activation_key`, `last_visit`, `created`, `modified`) VALUES
(1, 'shin', '0a5b040323620b6816502bd7eaea3133b82aceee', 'okada.shin@gmail.com', 1, 2, NULL, '2011-05-17 16:55:43', '2010-04-09 23:43:52', '2011-05-04 20:43:17'),
(2, 'anne', 'a0e865768dc0578a302aadcb5d83a9d8b7148ec1', 'cus7@gmail.com', 1, 1, NULL, '2010-11-07 05:56:52', '2010-08-04 21:29:28', '2010-10-27 08:11:53'),
(3, 'tonje', '74f4ad851b36a00062be49add78fa8b25eb2c3ac', 'cus2@gmail.com', 1, 1, NULL, '2010-11-05 11:21:19', '2010-08-04 21:30:39', NULL),
(4, 'demoadmin', '7209eff04cacade182becf6600f6cec0a4a2db37', 'admin@gmail.com', 1, 3, NULL, '2010-11-07 09:05:28', '2010-10-26 22:10:44', '2010-10-30 22:22:57');

-- --------------------------------------------------------

--
-- Table structure for table `be_user_profiles`
--

CREATE TABLE IF NOT EXISTS `be_user_profiles` (
  `user_id` int(10) unsigned NOT NULL,
  `company_name` varchar(100) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `web_address` varchar(100) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(30) NOT NULL,
  `post_code` int(10) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `be_user_profiles`
--

INSERT INTO `be_user_profiles` (`user_id`, `company_name`, `full_name`, `web_address`, `phone_number`, `address`, `city`, `post_code`) VALUES
(1, '', '', '', '', '', '', 0),
(2, '4children', 'Anne Will', 'http://yahoo.com', '', '', '', 0),
(3, 'Tonje Design', 'Tonje Smith', 'http://www.google.com', '', '', '', 0),
(4, '', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ci_sessions`
--

CREATE TABLE IF NOT EXISTS `ci_sessions` (
  `session_id` varchar(40) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `ip_address` varchar(16) CHARACTER SET latin1 NOT NULL DEFAULT '0',
  `user_agent` varchar(50) CHARACTER SET latin1 NOT NULL,
  `user_data` text NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `ci_sessions`
--

INSERT INTO `ci_sessions` (`session_id`, `ip_address`, `user_agent`, `user_data`, `last_activity`) VALUES
('570bfeb7441f8dffe64b7f60b72c364e', '0.0.0.0', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.2.1', 'a:10:{s:2:"id";s:1:"1";s:8:"username";s:4:"shin";s:5:"email";s:20:"okada.shin@gmail.com";s:8:"password";s:40:"0a5b040323620b6816502bd7eaea3133b82aceee";s:6:"active";s:1:"1";s:10:"last_visit";s:19:"2011-05-04 20:42:56";s:7:"created";s:19:"2010-04-09 23:43:52";s:8:"modified";s:19:"2011-05-04 20:43:17";s:5:"group";s:13:"Administrator";s:8:"group_id";s:1:"2";}', 1305643932),
('e34da7002a9a3fd90a19a57b9c9e5c0b', '0.0.0.0', 'Mozilla/5.0 (X11; U; Linux i686; en-GB; rv:1.9.2.1', 'a:10:{s:2:"id";s:1:"1";s:8:"username";s:4:"shin";s:5:"email";s:20:"okada.shin@gmail.com";s:8:"password";s:40:"0a5b040323620b6816502bd7eaea3133b82aceee";s:6:"active";s:1:"1";s:10:"last_visit";s:19:"2011-05-17 16:52:43";s:7:"created";s:19:"2010-04-09 23:43:52";s:8:"modified";s:19:"2011-05-04 20:43:17";s:5:"group";s:13:"Administrator";s:8:"group_id";s:1:"2";}', 1305644134);

-- --------------------------------------------------------

--
-- Table structure for table `demo_eventcal`
--

CREATE TABLE IF NOT EXISTS `demo_eventcal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(25) NOT NULL DEFAULT 'anonimous',
  `user_id` int(25) NOT NULL,
  `eventDate` date DEFAULT NULL,
  `eventTitle` varchar(100) DEFAULT NULL,
  `eventContent` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demo_eventcal`
--


-- --------------------------------------------------------

--
-- Table structure for table `demo_shoutbox`
--

CREATE TABLE IF NOT EXISTS `demo_shoutbox` (
  `id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user` varchar(25) NOT NULL DEFAULT 'anonimous',
  `user_id` int(5) NOT NULL,
  `message` varchar(255) NOT NULL DEFAULT '',
  `status` enum('to do','completed') NOT NULL DEFAULT 'to do',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `demo_shoutbox`
--


-- --------------------------------------------------------

--
-- Table structure for table `eventcal`
--

CREATE TABLE IF NOT EXISTS `eventcal` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user` varchar(25) NOT NULL DEFAULT 'anonimous',
  `user_id` int(25) NOT NULL,
  `eventDate` date DEFAULT NULL,
  `eventTitle` varchar(100) DEFAULT NULL,
  `eventContent` text,
  `privacy` enum('public','private') NOT NULL DEFAULT 'public',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `eventcal`
--

INSERT INTO `eventcal` (`id`, `user`, `user_id`, `eventDate`, `eventTitle`, `eventContent`, `privacy`) VALUES
(30, 'admin', 1, '2010-05-12', 'test', 'test', 'public'),
(31, 'shin', 1, '2010-08-11', 'school starts', 'yay', 'public');

-- --------------------------------------------------------

--
-- Table structure for table `omc_bookings`
--

CREATE TABLE IF NOT EXISTS `omc_bookings` (
  `booking_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `date_enroll` date NOT NULL,
  PRIMARY KEY (`booking_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=84 ;

--
-- Dumping data for table `omc_bookings`
--

INSERT INTO `omc_bookings` (`booking_id`, `customer_id`, `course_id`, `date_enroll`) VALUES
(73, 2, 11, '2010-10-22'),
(67, 4, 9, '2010-10-22'),
(66, 4, 11, '2010-10-22'),
(71, 2, 18, '2010-10-22'),
(65, 4, 1, '2010-10-22'),
(64, 4, 22, '2010-10-22'),
(68, 2, 2, '2010-10-22'),
(69, 2, 14, '2010-10-22'),
(62, 4, 37, '2010-10-22'),
(74, 2, 9, '2010-10-22'),
(72, 2, 1, '2010-10-22'),
(63, 4, 21, '2010-10-22'),
(61, 4, 2, '2010-10-22'),
(70, 2, 4, '2010-10-22'),
(60, 3, 9, '2010-10-22'),
(75, 2, 37, '2010-10-22'),
(76, 4, 18, '2010-10-22'),
(77, 3, 18, '2010-10-22'),
(78, 3, 14, '2010-10-22'),
(79, 3, 2, '2010-10-22'),
(80, 3, 19, '2010-10-22'),
(81, 4, 3, '2010-10-22'),
(82, 2, 3, '2010-10-22'),
(83, 1, 22, '2011-05-17');

-- --------------------------------------------------------

--
-- Table structure for table `omc_category`
--

CREATE TABLE IF NOT EXISTS `omc_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `shortdesc` varchar(255) NOT NULL,
  `longdesc` text NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `parentid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=110 ;

--
-- Dumping data for table `omc_category`
--

INSERT INTO `omc_category` (`id`, `name`, `shortdesc`, `longdesc`, `status`, `parentid`) VALUES
(102, 'Digital Downloads', 'Short Description', 'Long Description', 'active', 1),
(101, 'Movies, Music & Games', 'Short Description', 'Long Description', 'active', 1),
(99, 'Books', 'Here you can write a short description of books category.', 'Here you can write a long description of books category.', 'active', 1),
(1, 'Webshop', '', '', 'active', 0),
(107, 'Quicksand_products', '', '', 'active', 105),
(105, 'Quicksand', '', '', 'active', 0),
(100, 'CD', 'Here you can write a short description of this category.', 'Here you can write a long description of this category.', 'active', 1),
(103, 'Computers & Office', 'Short Description', 'Long Description', 'active', 1),
(104, 'Electronics', 'Short Description', 'Long Description', 'active', 1),
(108, 'Frontpage', '', '', 'active', 0),
(109, 'Slideshow', '', '', 'active', 108);

-- --------------------------------------------------------

--
-- Table structure for table `omc_colors`
--

CREATE TABLE IF NOT EXISTS `omc_colors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `omc_colors`
--


-- --------------------------------------------------------

--
-- Table structure for table `omc_courses`
--

CREATE TABLE IF NOT EXISTS `omc_courses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_id` int(10) DEFAULT NULL,
  `time` time NOT NULL,
  `course_name` varchar(255) DEFAULT NULL,
  `trainer_id` int(11) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  `capacity` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `order` int(11) DEFAULT NULL,
  `booked` int(5) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=38 ;

--
-- Dumping data for table `omc_courses`
--

INSERT INTO `omc_courses` (`id`, `date_id`, `time`, `course_name`, `trainer_id`, `desc`, `capacity`, `active`, `order`, `booked`, `type`) VALUES
(1, 5, '10:00:00', 'High Energy2', 1, 'Desc of Eric ', 2, 1, 0, 2, 'green'),
(2, 1, '11:00:00', 'Nets Pilates', 2, 'Nets Pilates tada', 3, 1, 2, 3, 'green'),
(3, 1, '13:00:00', 'Spin', 5, 'Description for Spin', 2, 1, 3, 2, 'red'),
(4, 1, '16:00:00', 'Sirkel30', 5, 'Description for Sirkel30', 2, 1, 4, 1, 'yellow'),
(5, 1, '16:00:00', 'Sirkel30', 5, 'Desc of Diana Krall. n arcu ut nisi sit auctor, enim. Phasellus, elementum mid, pulvinar, duis mus scelerisque? Ac eros? Augue penatibus quis aliquam odio augue! Duis dis sit integer tortor et, cras porttitor.', 2, 1, 0, 0, 'green'),
(9, 7, '11:00:00', 'High Energy', 6, 'Description for High energy', 3, 1, 1, 3, 'red'),
(11, 6, '11:00:00', 'Spin', 8, 'Description for Spin', 2, 1, 1, 2, 'blue'),
(12, 6, '13:00:00', 'High Energy', 2, 'Desc of High energy', 2, 1, 2, 0, 'yellow'),
(13, 6, '14:00:00', 'Spin', 8, '', 2, 1, 0, 0, 'red'),
(14, 3, '11:00:00', 'High Energy2', 9, 'desc of tal tada', 3, 1, 0, 2, 'yellow'),
(15, 8, '11:00:00', 'Rowing High', 9, 'Desc of Rowing High', 1, 1, 0, 0, 'green'),
(16, 9, '09:00:00', 'Jogging Rabbits', 6, 'Desc of Jogging Rabbits', 1, 1, 0, 0, 'blue'),
(17, 15, '09:00:00', 'Jogging Rabbits', 2, 'Desc of Jogging Rabbits', 1, 1, 0, 0, 'green'),
(18, 4, '10:00:00', 'Top speeds', 8, 'Desc about Top speed by fourplay', 2, 1, 0, 3, 'red'),
(19, 5, '10:00:00', 'High Energy2', 9, 'Desc about High Energy 2 by Tal', 1, 1, 0, 1, 'yellow'),
(20, 23, '10:00:00', 'High Energy2', 9, 'Desc of High energy 2 by Tal', 1, 1, 0, 0, 'yellow'),
(21, 3, '14:00:00', 'Nets Pilates', 2, 'Desc of Nets Pilates by Santana.', 2, 1, 0, 1, 'green'),
(22, 4, '15:00:00', 'Nets Pilates', 2, 'Desc of Nets Pilates by santana.', 2, 1, 0, 2, 'green'),
(37, 2, '08:00:00', 'High Energy2', 1, '', 3, 1, 0, 2, 'green');

-- --------------------------------------------------------

--
-- Table structure for table `omc_customer`
--

CREATE TABLE IF NOT EXISTS `omc_customer` (
  `customer_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `password` varchar(50) NOT NULL,
  `customer_first_name` varchar(50) NOT NULL,
  `customer_last_name` varchar(50) NOT NULL,
  `phone_number` int(10) unsigned NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `post_code` int(10) unsigned NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=103 ;

--
-- Dumping data for table `omc_customer`
--

INSERT INTO `omc_customer` (`customer_id`, `password`, `customer_first_name`, `customer_last_name`, `phone_number`, `email`, `address`, `city`, `post_code`) VALUES
(77, '7c4a8d09ca3762af', 'AAAAA', 'IIIIII', 54840015, 'doneara@yahoo.com', 'a/26', 'Den', 1245),
(78, '', 'gddh', 'hfhdfhdh', 123456657, 'cek@yahoo.com', 'sgsdgs gfgdfg', 'jakarta', 23342),
(79, '', 'werq', 'qer', 23655555, 'tt@dd.co', 'wert', 'wrt', 0),
(80, '6f4495945558382a', 'murugesh', 'murugesh', 4294967295, 'murugesh.tecz@gmail.com', 'dhandapani street', 'chennai', 600018),
(81, 'd032c9d61a177485', 'sooo', 'aaaaa', 9080760, 'news@club.fr', 'rte de l''avenir', 'paris', 75000),
(82, '', 'sooo', 'aaaaa', 9080760, 'news_sa@club-internet.fr', 'rte de l''avenir', 'paris', 75000),
(83, '3f53ef2834b9e19e', 'sha', 'alom', 1916909317, 'alom1_diu@yahoo.com', 'kahaloo bogra', 'dhaka', 12345),
(84, '', 'test', 'tes', 323287878, 'ingo@info.com', 'djdjdj', 'Denpasar', 223232),
(85, '', 'rex', 'doods', 12345678, 'adto@yahoo.com', 'sa', 'sdd', 454),
(86, '', 'test', 'test', 8611118, 'ibnu.hazim@yahoo.co.id', 'erdfsf', 'New York', 98811),
(87, '', 'afdas', 'fasdfasd', 23451234, 'fasdfsf@cscas.com', 'asdfasdfasdf', 'fasdf', 2344),
(88, '', 'gtreyhtru', 'yru', 4294967295, 'pallavisomani55@gmail.com', 'srfdh', 'hfj', 647),
(89, '', 'jojo', 'widarjo', 4294967295, 'jowidarjo@gmail.com', 'jl cikutra', 'bandung', 40191),
(90, '', 'aaa', 'sss', 111233456, '11@sss.css', 'doodo dsodo', 'ssas', 20302),
(91, '2a75b534574296ea', 'test', 'test', 123123123, 'test@test.com', '123,test adsf sh sfghf', 'asdfrsdf', 1232312),
(92, '86f7e437faa5a7fc', 'asddsf', 'asdfsdfsdf', 22222222, 'admin@gmail.com', 'a', 'a', 12343),
(93, 'fdb2a0805d2c7417', 'Petr', 'Hlavatý', 776886955, 'webillusioncz@gmail.com', '8 passage Montjovis, 87100 LIMOGES', 'xsxsxsxsx', 69301),
(94, '', 'ajus', 'suja', 98788888, 'guzdix@gmail.com', 'jjjj', 'ssss', 66666),
(95, '7ad762775d682e99', 'achuapa', 'achuapa', 12323133, 'achuapa2000@gmail.com', '12312 d dfsdf', 'Guatemala', 22002),
(96, 'a94a8fe5ccb19ba6', 'asdf', 'asdf', 4294967295, 'norbert@thedoughnutfactory.co.uk', 'dsfa', 'fasd', 455),
(97, '', 'FSGSDF', 'dfghdfg', 34563456, 'compleo25@gmail.com', 'sdf sdf #21', 'Tbilisi', 132),
(98, '', 'fds', 'fds', 12345678, 'dsa@dsa.dsa', 'dfsfds', 'ds', 12345),
(99, '', 'aadsggf', 'aadsdsd', 342343244, 'aaaa@aa.com', 'asd asd as', 'mmmm', 32344),
(100, 'a08f08bac39aeae6', 'Antonio', 'Falcetta', 12345678, 'antonio.falcetta@hotmail.it', '000dfsd', 'aaa', 70031),
(101, '', 'asa', 'asas', 1212121212, 'sasa@gmail.com', 'asasas', 'asasasa', 121),
(102, '789b49606c321c8c', 'Yanuel', 'Enriquez', 4294967295, 'playmaker37@gmail.com', '123123', 'testing', 6810);

-- --------------------------------------------------------

--
-- Table structure for table `omc_date`
--

CREATE TABLE IF NOT EXISTS `omc_date` (
  `date_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `week_id` int(10) NOT NULL,
  PRIMARY KEY (`date_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `omc_date`
--

INSERT INTO `omc_date` (`date_id`, `date`, `week_id`) VALUES
(1, '2010-10-11', 1),
(2, '2010-10-12', 1),
(3, '2010-10-13', 1),
(4, '2010-10-14', 1),
(5, '2010-10-15', 1),
(6, '2010-10-16', 1),
(7, '2010-10-17', 1),
(8, '2010-10-18', 2),
(9, '2010-10-19', 2),
(10, '2010-10-20', 2),
(11, '2010-10-21', 2),
(12, '2010-10-22', 2),
(13, '2010-10-23', 2),
(14, '2010-10-24', 2),
(15, '2010-10-25', 3),
(16, '2010-10-26', 3),
(18, '2010-10-28', 3),
(19, '2010-10-27', 3),
(20, '2010-10-29', 3),
(21, '2010-10-30', 3),
(22, '2010-10-31', 3),
(23, '2010-11-01', 4),
(24, '2010-11-02', 4),
(25, '2010-11-03', 4),
(26, '2010-11-04', 4),
(27, '2010-11-05', 4),
(28, '2010-11-06', 4),
(29, '2010-11-07', 4);

-- --------------------------------------------------------

--
-- Table structure for table `omc_files`
--

CREATE TABLE IF NOT EXISTS `omc_files` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) NOT NULL,
  `link` varchar(255) NOT NULL,
  `file_desc` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `omc_files`
--

INSERT INTO `omc_files` (`id`, `project_id`, `link`, `file_desc`, `active`) VALUES
(1, 1, 'www.box.net/shared/8svdaaay28', 'Photoshop files', 1),
(2, 1, 'sourceforge.net/projects/kaimonokago/', 'another files', 1);

-- --------------------------------------------------------

--
-- Table structure for table `omc_logs`
--

CREATE TABLE IF NOT EXISTS `omc_logs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `finish_time` time NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `log_entered_by` varchar(50) NOT NULL,
  `short_desc` varchar(255) NOT NULL,
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `omc_logs`
--

INSERT INTO `omc_logs` (`id`, `project_id`, `date`, `start_time`, `finish_time`, `active`, `log_entered_by`, `short_desc`, `note`) VALUES
(1, 1, '2010-10-27', '12:00:00', '14:00:00', 1, 'shin', 'Wireframe', '<p>bla bla</p>'),
(2, 1, '2010-10-28', '10:15:00', '13:00:00', 1, 'shin', 'another log', '<p>test</p>'),
(3, 1, '2010-10-29', '13:00:00', '16:30:00', 1, 'shin', 'Log log log', '<p>bla bla</p>'),
(4, 4, '2010-10-25', '14:20:00', '00:00:16', 1, 'shin', 'log for logo', '<p>bla bla</p>'),
(5, 1, '2010-10-30', '13:00:00', '15:50:00', 1, 'shin', 'test', '<p>test</p>');

-- --------------------------------------------------------

--
-- Table structure for table `omc_menu`
--

CREATE TABLE IF NOT EXISTS `omc_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `shortdesc` varchar(255) NOT NULL,
  `page_uri` varchar(60) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `parentid` int(10) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_uri`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=139 ;

--
-- Dumping data for table `omc_menu`
--

INSERT INTO `omc_menu` (`id`, `name`, `shortdesc`, `page_uri`, `status`, `parentid`, `order`) VALUES
(107, 'Webshop', '', '0', 'active', 0, 20),
(112, 'Webshop', '', 'webshop', 'active', 107, 10),
(113, 'About', '', 'about_us', 'active', 107, 20),
(114, 'Shopping guide', '', 'shopping_guide', 'active', 107, 30),
(115, 'Product information', '', 'productinformation', 'active', 114, 10),
(116, 'Gift card', '', 'gift_card', 'active', 114, 20),
(117, 'Shipping', '', 'shipping', 'active', 114, 30),
(118, 'Payment', '', '0', 'inactive', 114, 40),
(120, 'About copyright', '', '0', 'inactive', 114, 60),
(121, 'Products', '', '0', 'inactive', 107, 40),
(122, 'News', '', 'news', 'active', 107, 50),
(124, 'Contact us', '', 'contact_us', 'active', 107, 70),
(125, 'Go to checkout', 'shopping cart', 'checkout', 'active', 107, 80);

-- --------------------------------------------------------

--
-- Table structure for table `omc_messages`
--

CREATE TABLE IF NOT EXISTS `omc_messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `msg` text,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `omc_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `omc_order`
--

CREATE TABLE IF NOT EXISTS `omc_order` (
  `order_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) unsigned NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `order_date` datetime NOT NULL,
  `delivery_date` datetime NOT NULL,
  `payment_date` datetime NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=85 ;

--
-- Dumping data for table `omc_order`
--

INSERT INTO `omc_order` (`order_id`, `customer_id`, `total`, `order_date`, `delivery_date`, `payment_date`) VALUES
(60, 77, '804.00', '2010-07-09 15:04:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(61, 78, '536.00', '2010-07-10 10:25:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(62, 79, '24354.00', '2010-07-16 21:48:22', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(63, 80, '836.00', '2010-07-24 10:21:07', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(64, 80, '1490.00', '2010-07-24 10:24:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(65, 82, '686.00', '2010-07-26 20:06:28', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(66, 83, '536.00', '2010-07-30 11:33:14', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(67, 83, '536.00', '2010-07-30 11:39:06', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(68, 84, '2508.00', '2010-08-01 12:31:45', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(69, 85, '536.00', '2010-08-03 10:59:15', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(70, 86, '268.00', '2010-08-11 04:38:33', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(71, 87, '498.00', '2010-08-13 04:22:21', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(72, 88, '686.00', '2010-08-17 07:49:52', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(73, 89, '686.00', '2010-08-17 23:17:26', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(74, 90, '804.00', '2010-09-02 04:50:11', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(75, 91, '418.00', '2010-09-02 12:04:24', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(76, 92, '268.00', '2010-09-04 10:07:09', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(77, 94, '268.00', '2010-09-21 10:35:50', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(78, 96, '198.00', '2010-09-26 05:23:40', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(79, 97, '616.00', '2010-10-02 17:36:49', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(80, 98, '268.00', '2010-10-10 23:29:19', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(81, 99, '536.00', '2010-10-14 18:15:47', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(82, 100, '804.00', '2010-10-21 09:36:23', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(83, 101, '804.00', '2010-11-02 07:36:03', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(84, 102, '536.00', '2010-11-04 23:10:30', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `omc_order_item`
--

CREATE TABLE IF NOT EXISTS `omc_order_item` (
  `order_item_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `quantity` int(10) unsigned NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY (`order_item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=119 ;

--
-- Dumping data for table `omc_order_item`
--

INSERT INTO `omc_order_item` (`order_item_id`, `order_id`, `product_id`, `quantity`, `price`) VALUES
(84, 60, 97, 2, '268.00'),
(85, 60, 106, 1, '268.00'),
(86, 61, 78, 2, '268.00'),
(87, 62, 73, 123, '198.00'),
(88, 63, 105, 2, '418.00'),
(89, 64, 71, 3, '268.00'),
(90, 64, 72, 1, '268.00'),
(91, 64, 104, 1, '418.00'),
(92, 65, 79, 1, '268.00'),
(93, 65, 105, 1, '418.00'),
(94, 66, 77, 2, '268.00'),
(95, 67, 74, 2, '268.00'),
(96, 68, 75, 6, '418.00'),
(97, 69, 106, 2, '268.00'),
(98, 70, 77, 1, '268.00'),
(99, 71, 85, 1, '498.00'),
(100, 72, 82, 1, '268.00'),
(101, 72, 75, 1, '418.00'),
(102, 73, 105, 1, '418.00'),
(103, 73, 106, 1, '268.00'),
(104, 74, 78, 1, '268.00'),
(105, 74, 97, 2, '268.00'),
(106, 75, 105, 1, '418.00'),
(107, 76, 71, 1, '268.00'),
(108, 77, 106, 1, '268.00'),
(109, 78, 73, 1, '198.00'),
(110, 79, 75, 1, '418.00'),
(111, 79, 73, 1, '198.00'),
(112, 80, 97, 1, '268.00'),
(113, 81, 78, 2, '268.00'),
(114, 82, 79, 1, '268.00'),
(115, 82, 77, 1, '268.00'),
(116, 82, 89, 1, '268.00'),
(117, 83, 89, 3, '268.00'),
(118, 84, 77, 2, '268.00');

-- --------------------------------------------------------

--
-- Table structure for table `omc_page`
--

CREATE TABLE IF NOT EXISTS `omc_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `omc_page`
--

INSERT INTO `omc_page` (`id`, `name`, `keywords`, `description`, `path`, `content`, `status`, `category_id`) VALUES
(25, 'Web shop', '', '', 'webshop', '<h1>Your heading here.</h1>\n<h2>Content from weshop page in the back-end</h2>', 'active', 0),
(26, 'About us', '', '', 'about_us', '<h2>About us</h2>\nPellentesque habitant morbi trist', 'active', 0),
(27, 'Product information', '', '', 'productinformation', '<h2>Product information</h2>\nThunder, thundeercats! Thundercats!', 'active', 0),
(28, 'Shopping guide', '', '', 'shopping_guide', '<h1>Shopping guide</h1>\nTop Cat! The most effectual.', 'active', 0),
(29, 'Gift card', '', '', 'gift_card', '<h2>Gift card</h2>\nLorem ipsum dolor.', 'active', 0),
(30, 'Shipping', '', '', 'shipping', '<h2>Shipping information</h2><Lorem ipsum dolor sit ameerat', 'active', 0),
(33, 'News', '', '', 'news', '<h2>News</h2>\nUlysses, Ulyssese.', 'active', 0),
(35, 'Contact us', '', '', 'contact_us', 'Pellentesque ha leo.', 'active', 0),
(38, 'Go to checkout', '', '', 'checkout', '', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `omc_product`
--

CREATE TABLE IF NOT EXISTS `omc_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `shortdesc` varchar(255) NOT NULL,
  `longdesc` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `product_order` int(11) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `grouping` varchar(16) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL,
  `category_id` int(11) NOT NULL,
  `featured` enum('none','front','webshop') NOT NULL,
  `other_feature` enum('none','most sold','new product') NOT NULL,
  `price` float(7,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=142 ;

--
-- Dumping data for table `omc_product`
--

INSERT INTO `omc_product` (`id`, `name`, `shortdesc`, `longdesc`, `thumbnail`, `image`, `product_order`, `class`, `grouping`, `status`, `category_id`, `featured`, `other_feature`, `price`) VALUES
(71, 'Shortland', '', '', 'assets/images/digital_downloads/thumbnails/114x207_5.jpg', 'assets/images/digital_downloads/242x440_5.jpg', 0, '', '', 'active', 102, 'webshop', 'none', 268.00),
(72, 'D2301-01', '', '', 'assets/images/computers_&_office/thumbnails/114x207_8.jpg', 'assets/images/computers_&_office/242x440_8.jpg', 0, '', '', 'active', 102, 'webshop', 'new product', 268.00),
(73, 'Friendship', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_8.jpg', 'assets/images/movies,_music_&_games/242x440_8.jpg', 0, '', '', 'active', 102, 'webshop', 'none', 198.00),
(74, 'Placerat', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_9.jpg', 'assets/images/movies,_music_&_games/242x440_9.jpg', 0, '', '', 'active', 101, 'webshop', 'new product', 268.00),
(75, 'Elementum', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_2.jpg', 'assets/images/movies,_music_&_games/242x440_2.jpg', 0, '', '', 'active', 101, 'webshop', 'most sold', 418.00),
(76, 'Porttitor', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_10.jpg', 'assets/images/movies,_music_&_games/242x440_10.jpg', 0, '', '', 'active', 101, 'webshop', '', 268.00),
(77, 'Rerefe', '', '', 'assets/images/computers_&_office/thumbnails/114x207_17.jpg', 'assets/images/computers_&_office/242x440_17.jpg', 0, '', '', 'active', 103, 'webshop', 'most sold', 268.00),
(78, 'Rre resettr', '', '', 'assets/images/computers_&_office/thumbnails/114x207_11.jpg', 'assets/images/computers_&_office/242x440_11.jpg', 0, '', '', 'active', 103, 'webshop', 'most sold', 268.00),
(79, 'Pruyyuty', '', '', 'assets/images/computers_&_office/thumbnails/114x207_12.jpg', 'assets/images/computers_&_office/242x440_12.jpg', 0, '', '', 'active', 103, 'webshop', 'new product', 268.00),
(82, 'Gfwee', '', '', 'assets/images/books/thumbnails/114x207_14.jpg', 'assets/images/books/242x440_14.jpg', 0, '', '', 'active', 99, 'webshop', '', 268.00),
(84, 'Sjuer', '', '', 'assets/images/books/thumbnails/114x207_16.jpg', 'assets/images/books/242x440_16.jpg', 0, '', '', 'active', 99, 'webshop', '', 268.00),
(85, 'Isbjorn', '', '', 'assets/images/books/thumbnails/114x207_16.jpg', 'assets/images/books/242x440_16.jpg', 0, '', '', 'active', 99, 'webshop', 'most sold', 498.00),
(89, 'Medite eret', '', '', 'assets/images/books/thumbnails/114x207_17.jpg', 'assets/images/books/242x440_17.jpg', 0, '', '', 'active', 99, 'webshop', 'most sold', 268.00),
(97, 'Oyenter', '', '', 'assets/images/electronics/thumbnails/114x207_7.jpg', 'assets/images/electronics/242x440_7.jpg', 0, '', '', 'active', 104, 'webshop', 'most sold', 268.00),
(103, 'Ville hjempener', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_10.jpg', 'assets/images/movies,_music_&_games/242x440_10.jpg', 0, '', '', 'active', 104, 'webshop', 'most sold', 418.00),
(104, 'Den here ire ierrr tere', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_4.jpg', 'assets/images/movies,_music_&_games/242x440_4.jpg', 0, '', '', 'active', 104, 'webshop', 'new product', 418.00),
(105, 'Alvieun', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_7.jpg', 'assets/images/movies,_music_&_games/242x440_7.jpg', 0, '', '', 'active', 100, 'webshop', 'new product', 418.00),
(106, 'Truatu', '', '', 'assets/images/movies,_music_&_games/thumbnails/114x207_2.jpg', 'assets/images/movies,_music_&_games/242x440_2.jpg', 0, '', '', 'active', 100, 'webshop', 'most sold', 268.00),
(137, 'Big tree', '', '', '', 'assets/images/frontpage/big_tree.jpg', 0, '', '', 'active', 109, 'none', 'none', 0.00),
(138, 'Building', '', '', '', 'assets/images/frontpage/buil.jpg', 0, '', '', 'active', 109, 'none', 'none', 0.00),
(139, 'Station', '', '', '', 'assets/images/frontpage/station.jpg', 0, '', '', 'active', 109, 'none', 'none', 0.00),
(140, 'Sunset tree', '', '', '', 'assets/images/frontpage/sunset_tree.jpg', 0, '', '', 'active', 109, 'none', 'none', 0.00),
(141, 'Oak tree', '', '', '', 'assets/images/frontpage/The_Oak_tree.jpg', 0, '', '', 'active', 109, 'none', 'none', 0.00),
(126, 'Finder', '<p>1337 KB</p>', '', 'assets/images/quicksand_products/thumbnails/finder.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(124, 'Activity Monitor', '<p>234 KB</p>', '', 'assets/images/quicksand_products/thumbnails/Activity-Monitor.png', '', NULL, 'util', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(125, 'Address Book', '<p>1345 KB</p>', '', 'assets/images/quicksand_products/thumbnails/address-book.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(127, 'Front Row', '<p>401 KB</p>', '', 'assets/images/quicksand_products/thumbnails/front-row.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(131, 'Interface Builder', '<p>2746 KB</p>', '', 'assets/images/quicksand_products/thumbnails/interface-builder.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(132, 'iTune', '<p>17612 KB</p>', '', 'assets/images/quicksand_products/thumbnails/ituna.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(133, 'TextEdit', '<p>1669 KB</p>', '', 'assets/images/quicksand_products/thumbnails/textedit.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(134, 'Keychain Access', '<p>972 KB</p>', '', 'assets/images/quicksand_products/thumbnails/keychain-access.png', '', NULL, 'util', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(128, 'Google Pokemon', '<p>12875 KB</p>', '', 'assets/images/quicksand_products/thumbnails/google-pokemon.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(129, 'iCal', '<p>5273 KB</p>', '', 'assets/images/quicksand_products/thumbnails/ical.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(130, 'iChat', '<p>5437 KB</p>', '', 'assets/images/quicksand_products/thumbnails/ichat.png', '', NULL, 'app', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(135, 'Network Utility', '<p>245 KB</p>', '', 'assets/images/quicksand_products/thumbnails/network-utility.png', '', NULL, 'util', 'quicksand', 'active', 107, 'none', 'none', 0.00),
(136, 'Sync', '<p>3788 KB</p>', '', 'assets/images/quicksand_products/thumbnails/sync.png', '', NULL, 'util', 'quicksand', 'active', 107, 'none', 'none', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `omc_product_colors`
--

CREATE TABLE IF NOT EXISTS `omc_product_colors` (
  `product_id` int(11) NOT NULL,
  `color_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`color_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `omc_product_colors`
--


-- --------------------------------------------------------

--
-- Table structure for table `omc_product_sizes`
--

CREATE TABLE IF NOT EXISTS `omc_product_sizes` (
  `product_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  PRIMARY KEY (`product_id`,`size_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `omc_product_sizes`
--


-- --------------------------------------------------------

--
-- Table structure for table `omc_projects`
--

CREATE TABLE IF NOT EXISTS `omc_projects` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) NOT NULL,
  `project_name` varchar(255) NOT NULL,
  `total_hr` int(10) NOT NULL,
  `created_by` varchar(50) NOT NULL,
  `active` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `note` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `omc_projects`
--

INSERT INTO `omc_projects` (`id`, `customer_id`, `project_name`, `total_hr`, `created_by`, `active`, `note`) VALUES
(1, 2, 'Website', 30, 'shin', 1, '<p>Creating a new website. Bla bla bla bla</p>'),
(4, 2, 'Logo', 10, 'shin', 1, 'create a smashing logo'),
(5, 3, 'News letter', 10, 'shin', 1, 'Note for news letter design'),
(6, 3, 'test', 20, '', 1, 'test'),
(7, 3, 'test1', 0, '', 1, 'test1');

-- --------------------------------------------------------

--
-- Table structure for table `omc_sizes`
--

CREATE TABLE IF NOT EXISTS `omc_sizes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `omc_sizes`
--


-- --------------------------------------------------------

--
-- Table structure for table `omc_specs`
--

CREATE TABLE IF NOT EXISTS `omc_specs` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `project_id` int(10) NOT NULL,
  `spec_desc` varchar(255) NOT NULL,
  `spec_details` text,
  `created_by` varchar(20) NOT NULL,
  `date_created` date NOT NULL,
  `date_completed` date DEFAULT NULL,
  `completed_by` varchar(20) DEFAULT '',
  `active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `omc_specs`
--

INSERT INTO `omc_specs` (`id`, `project_id`, `spec_desc`, `spec_details`, `created_by`, `date_created`, `date_completed`, `completed_by`, `active`) VALUES
(1, 1, 'Spec for index page', '<p>The details for the spec here.</p>', 'shin', '2010-10-27', '2010-10-27', 'shin', 1),
(2, 1, 'anoterh spec', '<p>Details here bla bla.</p>', 'shin', '2010-10-28', NULL, 'shin', 1),
(4, 1, 'Here is another spec', '<p>details details</p>', 'shin', '2010-10-28', NULL, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `omc_subscribers`
--

CREATE TABLE IF NOT EXISTS `omc_subscribers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `omc_subscribers`
--

INSERT INTO `omc_subscribers` (`id`, `name`, `email`) VALUES
(46, 'test', 'test@test.com');

-- --------------------------------------------------------

--
-- Table structure for table `omc_trainer`
--

CREATE TABLE IF NOT EXISTS `omc_trainer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `trainer_name` varchar(50) NOT NULL,
  `trainer_image` varchar(100) NOT NULL,
  `video_url` text NOT NULL,
  `desc` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `omc_trainer`
--

INSERT INTO `omc_trainer` (`id`, `trainer_name`, `trainer_image`, `video_url`, `desc`) VALUES
(1, 'Eric Clapton Jr.', '', 'http://www.youtube.com/watch?v=AscPOozwYA8', 'Desc of Eric '),
(2, 'Sussan Santana', '', 'http://www.youtube.com/watch?v=ACdwCIld3kE&feature=related', 'Desc of Santana'),
(6, 'Joe Cocker', '', 'http://www.youtube.com/watch?v=wlDmslyGmGI', 'Trainer 6''s desc. Trainer is Joe cocker'),
(7, 'Jeff Beck', '', 'http://www.youtube.com/watch?v=VC02wGj5gPw', 'Desc of Jeff Beck. mattis? Mus est? Porttitor nascetur urna integer a, adipiscing rhoncus! Elementum ut sed eros platea et proin et elementum augue in. In nunc magnis augue tincidunt? Tempor et odio et odio tempor lorem sed, aliquam, adipisc'),
(5, 'Diana Krall', '', 'http://www.youtube.com/watch?v=it1NaXrIN9I', 'Desc of Diana Krall. n arcu ut nisi sit auctor, enim. Phasellus, elementum mid, pulvinar, duis mus scelerisque? Ac eros? Augue penatibus quis aliquam odio augue! Duis dis sit integer tortor et, cras porttitor.'),
(8, 'Fourplay', '', 'http://www.youtube.com/watch?v=wXNK2refwpY&feature=related', 'Desc of Fourplay. por lorem sed, aliquam, adipiscing non non! Enim massa. Etiam enim sed! Rhoncus diam porttitor nisi, ac tri'),
(9, 'Tal Wilkenfeld ', '', 'http://www.youtube.com/watch?v=6qQvNhvAByM&feature=related', 'Desc of Tal wilkenfeld.  tempor lorem sed, aliquam, adipiscing non non! Enim massa. Etiam enim sed! Rhoncus diam porttitor nisi, ac tri');

-- --------------------------------------------------------

--
-- Table structure for table `omc_week`
--

CREATE TABLE IF NOT EXISTS `omc_week` (
  `week_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  PRIMARY KEY (`week_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `omc_week`
--

INSERT INTO `omc_week` (`week_id`, `name`) VALUES
(1, 'Uke 41'),
(2, 'Uke 42'),
(3, 'Uke 43'),
(4, 'Uke 44'),
(8, 'Uke 40');

-- --------------------------------------------------------

--
-- Table structure for table `port_category`
--

CREATE TABLE IF NOT EXISTS `port_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `shortdesc` varchar(255) NOT NULL,
  `longdesc` text NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `parentid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `port_category`
--

INSERT INTO `port_category` (`id`, `name`, `shortdesc`, `longdesc`, `status`, `parentid`) VALUES
(2, 'Portfolio', '<p>Our <span>portfolio</span>, home to our latest, and greatest work.</p>', '<div class="grid_3 textright"><span class="meta">Cross-browser tested</span>\n<h4 class="title ">Portfolio</h4>\n<div class="hr clearfix dotted">&nbsp;</div>\n<p>Cras vestibulum lorem et dui mollis sed posuere leo semper. Integer ac ultrices neque. Cras lacinia orci a augue tempor egestas. Sed cursus, sem ut vehicula vehicula, ipsum est mattis justo, at volutpat nibh arcu sit amet risus.</p>\n</div>', 'active', 0),
(3, 'Websites', '<p>Website category short descriptions.</p>', '<p>Website category long descriptions.</p>', 'active', 2),
(4, 'Logos', '<p>Logos category short descriptions.</p>', '<p>Logos category long descriptions.</p>', 'active', 2),
(5, 'Prints', '<p>Prints category short descriptions.</p>', '<p>Print category long descriptions.</p>', 'active', 2);

-- --------------------------------------------------------

--
-- Table structure for table `port_menu`
--

CREATE TABLE IF NOT EXISTS `port_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `shortdesc` varchar(255) NOT NULL,
  `page_uri` varchar(60) NOT NULL,
  `status` enum('active','inactive') NOT NULL,
  `parentid` int(10) NOT NULL,
  `order` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `page_id` (`page_uri`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `port_menu`
--

INSERT INTO `port_menu` (`id`, `name`, `shortdesc`, `page_uri`, `status`, `parentid`, `order`) VALUES
(1, 'Aurelius', '', '0', 'active', 0, 10),
(2, 'Home', 'Homepage', '0', 'active', 1, 50),
(3, 'About', 'Who are we?', 'about', 'active', 1, 40),
(4, 'Portfolio', 'Our latest work', 'category', 'active', 1, 30),
(5, 'Services', 'Our services', 'services', 'active', 1, 20),
(6, 'Contact us', 'Get in touch', 'contact', 'active', 1, 10);

-- --------------------------------------------------------

--
-- Table structure for table `port_page`
--

CREATE TABLE IF NOT EXISTS `port_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `keywords` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `path` varchar(255) NOT NULL DEFAULT '',
  `content` text NOT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `category_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `port_page`
--

INSERT INTO `port_page` (`id`, `name`, `keywords`, `description`, `path`, `content`, `status`, `category_id`) VALUES
(40, 'Home', '', '', 'frontpage', '<h2 class="grid_12 caption clearfix">Welcome! This is <span>Aurelius</span>, a slick, professional <span style="text-decoration: underline;">Business</span> &amp; <span style="text-decoration: underline;">Portfolio</span> theme built to engage the user in your work.</h2>\n<div class="hr grid_12 clearfix quicknavhr">&nbsp;</div>\n<div id="quicknav" class="grid_12"><a class="quicknavgrid_3 quicknav alpha" href="portfolio/pages/portfolio">\n<h4 class="title ">Recent Work</h4>\n<p>Cras vestibulum lorem et dui mollis sed posuere leo semper.</p>\n<p style="text-align: center;"><img src="assets/images/aurelius/Art_Artdesigner.lv.png" alt="" /></p>\n</a> <a class="quicknavgrid_3 quicknav" href="portfolio/pages/about">\n<h4 class="title ">Learn about us</h4>\n<p>Cras vestibulum lorem et dui mollis sed posuere leo semper.</p>\n<p style="text-align: center;"><img src="assets/images/aurelius/info.png" alt="" /></p>\n</a> <a class="quicknavgrid_3 quicknav" href="portfolio/pages/service">\n<h4 class="title ">Read our services</h4>\n<p>Cras vestibulum lorem et dui mollis sed posuere leo semper.</p>\n<p style="text-align: center;"><img src="assets/images/aurelius/Blog_Artdesigner.lv.png" alt="" /></p>\n</a> <a class="quicknavgrid_3 quicknav" href="#">\n<h4 class="title ">Follow on Twitter</h4>\n<p>Cras vestibulum lorem et dui mollis sed posuere leo semper.</p>\n<p style="text-align: center;"><img src="assets/images/aurelius/hungry_bird.png" alt="" /></p>\n</a></div>', 'active', 0),
(41, 'About us', 'about us', '', 'about', '<h2 class="grid_12 caption">Learn <span>about us</span> and what we do best.</h2>\n<div class="hr grid_12 clearfix">&nbsp;</div>\n<div class="grid_8">\n<h4 class="page_title">Our mission</h4>\n<div class="hr dotted clearfix">&nbsp;</div>\n<p><em>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</em></p>\n<h4 class="page_title">So who are we?</h4>\n<div class="hr dotted clearfix">&nbsp;</div>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>\n<h4 class="page_title">Staff</h4>\n<div class="hr dotted clearfix">&nbsp;</div>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>\n<h4 class="page_title">Clients</h4>\n<div class="hr dotted clearfix">&nbsp;</div>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>\n</div>\n<div class="grid_4">\n<h4>Our History</h4>\n<div class="hr dotted clearfix">&nbsp;</div>\n<dl class="history"> <dt>1994</dt> <dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> <dt>1996</dt> <dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> <dt>2000</dt> <dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> <dt>2003</dt> <dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> <dt>2009</dt> <dd>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor.</dd> </dl></div>', 'active', 0),
(42, 'Portfolio', 'portfolio', '', 'category', '<p>Our <span>portfolio</span>, home to our latest, and greatest work.</p>', 'active', 0),
(43, 'Services', 'services', '', 'services', '<h4 class="page_title">Our services</h4>\n<div class="hr dotted clearfix">&nbsp;</div>\n<p><em>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</em></p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi velgue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla vel diam id mauris accumsan egestas. Sed sed lorem. Integera vel diam id mauris accumsan egestas. Sed sed lorem. Integer id mi vel sapien fermentum vehicula. Pellentesque vitae lacus a sem posuere fringilla. Vestibulum dolor. Phasellus cursus augue ac purus. Curabitur faucibus. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.</p>', 'active', 0),
(44, 'Contact us', 'contact us', '', 'contact', '<p>&lt;!-- Column 1 / Content --&gt;</p>\n<div class="grid_8">\n<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vel porta erat. Quisque sit amet risus at odio pellentesque sollicitudin. Proin suscipit molestie facilisis. Aenean vel massa magna. Proin nec lacinia augue. Mauris venenatis libero nec odio viverra consequat. In hac habitasse platea dictumst.</p>\n</div>', 'active', 0);

-- --------------------------------------------------------

--
-- Table structure for table `port_product`
--

CREATE TABLE IF NOT EXISTS `port_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `shortdesc` varchar(255) NOT NULL,
  `longdesc` text NOT NULL,
  `thumbnail` varchar(255) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `product_order` int(11) DEFAULT NULL,
  `class` varchar(255) DEFAULT NULL,
  `grouping` varchar(16) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL,
  `category_id` int(11) NOT NULL,
  `featured` enum('none','front','webshop') NOT NULL,
  `other_feature` enum('none','most sold','new product') NOT NULL,
  `price` float(7,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `port_product`
--

INSERT INTO `port_product` (`id`, `name`, `shortdesc`, `longdesc`, `thumbnail`, `image`, `product_order`, `class`, `grouping`, `status`, `category_id`, `featured`, `other_feature`, `price`) VALUES
(1, 'Website 1', '<p>website 1 short description</p>', '<p>website 1 long description</p>', '<p><img src="../../../assets/images/websites/thumbnails/website1_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/websites/website1_600x300.gif" alt="" /></li>\n<li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li>\n<li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li>\n<li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li>\n<li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 3, 'front', 'none', 0.00),
(2, 'Website 2', '<p>website 2 short description</p>', '<p>website 2 long description</p>', '<p><img src="../../../assets/images/websites/thumbnails/website2_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/websites/website2_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 3, 'front', 'none', 0.00),
(3, 'Website 3', '<p>website 3 short description</p>', '<p>website 3 long description</p>', '<p><img src="../../../assets/images/websites/thumbnails/website3_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/websites/website3_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 3, 'none', 'none', 0.00),
(4, 'Website 4', '<p>website 4 short description</p>', '<p>website 4 long description</p>', '<p><img src="../../../assets/images/websites/thumbnails/website4_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/websites/website4_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 3, 'front', 'none', 0.00),
(5, 'Website 5', '<p>website 5 short description</p>', '<p>website 5 long description</p>', '<p><img src="../../../assets/images/websites/thumbnails/website5_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/websites/website5_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 3, 'none', 'none', 0.00),
(6, 'Logo 1', '<p>Logo 1 short description</p>', '<p>Logo 2 long description</p>', '<p><img src="../../assets/images/logos/thumbnails/logo1_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/logos/logo1_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 4, 'front', 'none', 0.00),
(7, 'Logo 2', '<p>Logo 2 short description</p>', '<p>Logo 2 long description</p>', '<p><img src="../../assets/images/logos/thumbnails/logo2_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/logos/logo2_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 4, 'front', 'none', 0.00),
(8, 'Logo 3', '<p>Logo 3 short description</p>', '<p>Logo 3 long description</p>', '<p><img src="../../assets/images/logos/thumbnails/logo3_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/logos/logo3_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 4, 'none', 'none', 0.00),
(9, 'Logo 4', '<p>Logo 4 short description</p>', '<p>Logo 4 long description</p>', '<p><img src="../../assets/images/logos/thumbnails/logo4_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/logos/logo4_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'inactive', 4, 'none', 'none', 0.00),
(10, 'Logo 5', '<p>Logo 5 short description</p>', '<p>Logo 5 long description</p>', '<p><img src="../../assets/images/logos/thumbnails/logo5_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/logos/logo5_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 4, 'none', 'none', 0.00),
(11, 'Print 1', '<p>Print 1 short description</p>', '<p>Print 1 long description</p>', '<p><img src="../../assets/images/prints/thumbnails/print1_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/prints/print1_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 5, 'front', 'none', 0.00),
(12, 'Print 2', '<p>Print 2 short description</p>', '<p>Print 2 long description</p>', '<p><img src="../../assets/images/prints/thumbnails/print2_223x112.gif" alt="" width="223" height="112" /></p>', '<li><span>Homepage</span><img src="../../../assets/images/prints/print2_600x300.gif" alt="" /></li> <li><span>Content Page</span><img src="../../../assets/images/support_images/imageA_600x300.gif" alt="" /></li> <li><span>Dropdown Menu</span><img src="../../../assets/images/support_images/imageB_600x300.gif" alt="" /></li> <li><span>Comments List</span><img src="../../../assets/images/support_images/imageC_600x300.gif" alt="" /></li> <li><span>Comment Form</span><img src="../../../assets/images/support_images/imageD_600x300.gif" alt="" /></li>', 0, '', '', 'active', 5, 'front', 'none', 0.00);

-- --------------------------------------------------------

--
-- Table structure for table `shoutbox`
--

CREATE TABLE IF NOT EXISTS `shoutbox` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user` varchar(25) NOT NULL DEFAULT 'anonimous',
  `user_id` int(25) NOT NULL,
  `message` varchar(255) NOT NULL DEFAULT '',
  `status` enum('to do','completed') NOT NULL DEFAULT 'to do',
  `privacy` enum('public','private') NOT NULL DEFAULT 'public',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=132 ;

--
-- Dumping data for table `shoutbox`
--


-- --------------------------------------------------------

--
-- Table structure for table `support_details`
--

CREATE TABLE IF NOT EXISTS `support_details` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `customer_id` int(10) NOT NULL,
  `date` date NOT NULL,
  `time` int(10) NOT NULL,
  `point_credit` int(10) NOT NULL,
  `note` text NOT NULL,
  `details` text NOT NULL,
  `by` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `support_details`
--

INSERT INTO `support_details` (`id`, `customer_id`, `date`, `time`, `point_credit`, `note`, `details`, `by`) VALUES
(39, 2, '2010-08-04', 0, 180, 'test entry 1', '', 'shin'),
(40, 2, '2010-08-05', 30, 0, 'Menu modification', 'Changing color, position and width etc.', 'shin'),
(41, 2, '2010-08-06', 20, 0, 'Changing header image', 'From image A to image B', 'shin'),
(42, 3, '2010-08-07', 0, 120, 'Credit paid on 7th Aug 2010', '', 'shin'),
(43, 3, '2010-08-08', 40, 0, 'Changing slideshow', 'Changed the index page slideshow to jquery.', 'shin'),
(44, 3, '2010-08-14', 50, 0, 'Footer change', 'More details entered to Footer.', 'shin'),
(45, 3, '2010-08-22', 0, 180, 'paid on 22th Aug 2010', '', 'shin'),
(46, 3, '2010-08-29', 150, 0, 'Changing to HTML 5', 'tags are changed, js added etc.', 'shin');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `be_acl_permissions`
--
ALTER TABLE `be_acl_permissions`
  ADD CONSTRAINT `be_acl_permissions_ibfk_1` FOREIGN KEY (`aro_id`) REFERENCES `be_acl_groups` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `be_acl_permissions_ibfk_2` FOREIGN KEY (`aco_id`) REFERENCES `be_acl_resources` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `be_acl_permission_actions`
--
ALTER TABLE `be_acl_permission_actions`
  ADD CONSTRAINT `be_acl_permission_actions_ibfk_1` FOREIGN KEY (`access_id`) REFERENCES `be_acl_permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `be_acl_permission_actions_ibfk_2` FOREIGN KEY (`axo_id`) REFERENCES `be_acl_actions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `be_groups`
--
ALTER TABLE `be_groups`
  ADD CONSTRAINT `be_groups_ibfk_1` FOREIGN KEY (`id`) REFERENCES `be_acl_groups` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `be_resources`
--
ALTER TABLE `be_resources`
  ADD CONSTRAINT `be_resources_ibfk_1` FOREIGN KEY (`id`) REFERENCES `be_acl_resources` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `be_users`
--
ALTER TABLE `be_users`
  ADD CONSTRAINT `be_users_ibfk_1` FOREIGN KEY (`group`) REFERENCES `be_acl_groups` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `be_user_profiles`
--
ALTER TABLE `be_user_profiles`
  ADD CONSTRAINT `be_user_profiles_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `be_users` (`id`) ON DELETE CASCADE;
